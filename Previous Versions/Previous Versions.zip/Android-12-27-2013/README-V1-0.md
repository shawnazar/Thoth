Milestones reached.
<br/><br/><br/>
-Android SDK Setup<br/>
-Git Account, And Colab setup.<br/>
-Snapshot function to capture an image<br/>
