Version 1.1<br>
-----------
<br>
<br>
This version will will furthur our advance into the camera. Now that we
can take a image we will start to create classes based on our actions.<br>
<br>
-Storage<br>
** Store images
</body>
</html>
