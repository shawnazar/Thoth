package com.thoth;

public class Thoth 
{
	/* <b>Thoth System Configuration</b> */
	public static final String ALBUM_TITLE = "Thoth Gallery";
}
